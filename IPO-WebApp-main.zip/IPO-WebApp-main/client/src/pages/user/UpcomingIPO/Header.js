import React from "react";
import "./Header.css"; // Ensure this is the correct path to your CSS file
import logo from "./assets/logo1.jpeg"; // Update the path to your logo image
import grid from "./assets/grip-vertical.png"; // Update the path to your grid image
const Header = () => {
  return (
    <header className="header">
      <div className="header__logo-section">
        <img src={logo} alt="Bluestock Logo" className="header__logo" />
        <span className="header__title">BLUESTOCK</span>
      </div>
      <nav className="header__nav">
        <a href="#products">Products</a>
        <a href="#pricing">Pricing</a>
        <a href="#community">Community</a>
        <a href="#media">Media</a>
        <a href="#support">Support</a>
      </nav>
      <div className="header__actions">
        <a href="#signin" className="header__signin">Sign In</a>
        <a href="#signup" className="header__signup">Sign Up Now</a>
        <img src={grid} alt="grid" className="grid-nav" />
      </div>
    </header>
  );
};

export default Header;