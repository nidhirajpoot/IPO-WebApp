import React from "react";
import "./Footer.css"; // Create a CSS file for styles
import startup from './assets/startup india image.png'
import logo from './assets/logo1.jpeg'
const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-sections">
        <div className="footer-column">
          <h4>Resources</h4>
          <ul>
            <li><a href="#">Trading View</a></li>
            <li><a href="#">NSE Holidays</a></li>
            <li><a href="#">e-Voting CDSL</a></li>
            <li><a href="#">e-Voting NSDL</a></li>
            <li><a href="#">Market Timings</a></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Company</h4>
          <ul>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Contact Us</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Community</a></li>
            <li><a href="#">Blogs</a></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Offerings</h4>
          <ul>
            <li><a href="#">Compare Broker</a></li>
            <li><a href="#">Fin Calculators</a></li>
            <li><a href="#">IPO</a></li>
            <li><a href="#">All Brokers</a></li>
            <li><a href="#">Products</a></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Links</h4>
          <ul>
            <li><a href="#">Shark Investor</a></li>
            <li><a href="#">Mutual Funds</a></li>
            <li><a href="#">Sitemap</a></li>
            <li><a href="#">Indian Indices</a></li>
            <li><a href="#">Bug Bounty Program</a></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Policy</h4>
          <ul>
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Refund Policy</a></li>
            <li><a href="#">Disclaimer</a></li>
            <li><a href="#">Trust & Security</a></li>
          </ul>
        </div>
      </div>
      <div className="footer-section2">
      <div className="footer-contact">
      <div className="footer-icons">
          <a href="#"><i className="fab fa-x-twitter"></i></a>
          <a href="#"><i className="fab fa-facebook"></i></a>
          <a href="#"><i className="fab fa-youtube"></i></a>
          <a href="#"><i className="fab fa-linkedin"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
          <a href="#"><i className="fab fa-telegram"></i></a>
        </div>
        <div className="footer-company-name">
        <img src={logo} alt='logo'></img>
         <span> Bluestock</span>
        </div>
        <div className="footer-company-address">
        <p>Bluestock Fintech</p>
        <p>Pune, Maharashtra</p>
        </div>
        <div className="footer-company-iso">
        <p>MSME Registration No: </p>
        <p>UDYAM-MH-01-0138001</p>
        </div>
        <img src={startup} alt="ISO" />
      </div>

      <div className="footer-disclaimer">
        <p>
          Investment in securities markets are subject to market risks, read all the related documents carefully before investing as prescribed by SEBI. Issued in the interest of the investors.
        </p>
        <p>
          The users can write to <a href="mailto:hello@bluestock.in">hello@bluestock.in</a> for any app or website-related queries. Also you can send IT / Tech related feedback to <a href="mailto:cto@bluestock.in">cto@bluestock.in</a>
        </p>
        <p>
        Disclaimer: We are not a SEBI registered research analyst company. We do not provide any kind of stock recommendations, buy/sell stock tips, or investment and trading advice. All the stock scripts shown in the Bluestock app, website, all social media handles are for educational purposes only.
        <p>
        Before making any investment in the financial market, it is advisable to consult with your financial advisor. Remember that stock markets are subject to market risks.
        </p>
        </p>
        
      </div>
      </div>
      <div className="footer-bottom-parent">

      
    <div className="footer1-bottom">
        <p>Bluestock Fintech All Rights Reserved.</p>
    </div>
    <div className="footer-bottom">
        <p>Made with <span>&#10084;</span> in Pune, Maharashtra</p>
      
      </div>
    </div>
    </footer>
  );
};

export default Footer;
