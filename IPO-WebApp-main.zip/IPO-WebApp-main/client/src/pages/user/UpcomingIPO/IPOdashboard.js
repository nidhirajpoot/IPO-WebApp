
import React, { useState, useEffect } from "react";
import "./IPOdashboard.css";
import IPOCard from "./IPO_Card";
import left_arrow_icon from "./assets/left_arrow_icon.svg";
import right_arrow_icon from "./assets/right_arrow_icon.svg";

const IPOdashboard = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [ipoData, setIpoData] = useState([]);
  const [filteredIPOs, setFilteredIPOs] = useState(ipoData);

  const [priceFrom, setPriceFrom] = useState("");
  const [priceTo, setPriceTo] = useState("");
  const [openDate, setOpenDate] = useState("");
  const [closeDate, setCloseDate] = useState("");
  const [issueSize, setIssueSize] = useState("");
  const [selectedIssueType, setSelectedIssueType] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:3001/api/ipos")
      .then((response) => response.json())
      .then((data) => {
        setIpoData(data);
        setFilteredIPOs(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching IPO data:", error);
        setLoading(false);
      });
  }, []);
  const clearFilters = () => {
    setPriceFrom('');
    setPriceTo('');
    setOpenDate('');
    setCloseDate('');
    setIssueSize('');
    setSelectedIssueType('');
    setFilteredIPOs(ipoData);
  };
 
  useEffect(() => {
    const issuedIpos = ipoData.filter((ipo) => {
      // Extract min and max from priceband: "Rs 39 - 41"
      let minPrice = null, maxPrice = null;
      if (ipo.priceband !== "Not Issued") {
        const match = ipo.priceband.match(/Rs\s*(\d+)\s*-\s*(\d+)/);
        if (match) {
          minPrice = parseInt(match[1], 10);
          maxPrice = parseInt(match[2], 10);
        }
      }
  
      const matchesPrice =
        (!priceFrom || (minPrice !== null && minPrice >= parseInt(priceFrom))) &&
        (!priceTo || (maxPrice !== null && maxPrice <= parseInt(priceTo)));
  
      const matchesOpenDate =
        !openDate || (ipo.open !== "Not Issued" && ipo.open === openDate) || ipo.open !== "Not Issued";
  
      const matchesCloseDate =
        !closeDate || (ipo.close !== "Not Issued" && ipo.close === closeDate) || ipo.close !== "Not Issued";
  
      const matchesIssueSize =
        !issueSize || (ipo.issueSize !== "Not Issued" && parseInt(ipo.issueSize) <= parseInt(issueSize)) || ipo.issueSize === "Not Issued";
  
      const matchesIssueType =
        !selectedIssueType || (ipo.issueType !== "Not Issued" && ipo.issueType === selectedIssueType) || ipo.issueType !== "Not Issued";
  
      return matchesPrice && matchesOpenDate && matchesCloseDate && matchesIssueSize && matchesIssueType;
    });
  
    setFilteredIPOs(issuedIpos);
  }, [priceFrom, priceTo, openDate, closeDate, issueSize, selectedIssueType]);
  
  if (loading) return <p>Loading IPO data...</p>;

  return (
    <div className="dashboard">
      <div className="box">
        <div className="section1">
          <div className="page-path">
            <span className="home-path">Bluestock</span>
            <span>{">"}</span>
            <span className="ipo-path">IPO</span>
            <span>{">"}</span>
            <span id="upcoming-ipo-path">UPCOMING IPO</span>
          </div>
          <div className="dashboard-title">Upcoming IPO</div>
          <p className="p">
            Companies that have filed for an IPO with SEBI. Few details might be
            disclosed by the companies later.
          </p>
        </div>
      </div>

      <div className="container">
        {/* Filtering Section */}
        <div className="filter">
        <div className="filter-box">
          <h5>Filters</h5>
          <button className="clear-btn" onClick={clearFilters}>Clear </button>
          </div>
          {/* Price Band Filter */}
          <div className="filter-type price-band-filter">
            <p className="filter-title">Price Band</p>
            <div className="band-filter">
              <input
                type="number"
                min={0}
                placeholder="From"
                value={priceFrom}
                onChange={(e) => setPriceFrom(e.target.value)}
              />
              <span>To</span>
              <input
                type="number"
                min={0}
                placeholder="To"
                value={priceTo}
                onChange={(e) => setPriceTo(e.target.value)}
              />
            </div>
          </div>

          {/* Open & Close Date Filters */}
          <div className="filter-type dates-filter">
            <div className="opening-date-filter">
              <p className="filter-title">Open Date</p>
              <input
                type="date"
                value={openDate}
                onChange={(e) => setOpenDate(e.target.value)}
              />
            </div>
            <div className="closing-date-filter">
              <p className="filter-title">Close Date</p>
              <input
                type="date"
                value={closeDate}
                onChange={(e) => setCloseDate(e.target.value)}
              />
            </div>
          </div>

          {/* Issue Size Filter */}
          <div className="filter-type issue-size-filter">
            <p className="filter-title">Issue Size &lt; (Cr)</p>
            <input
              type="number"
              min={0}
              value={issueSize}
              onChange={(e) => setIssueSize(e.target.value)}
            />
          </div>

          {/* Issue Type Filter */}
          <div className="filter-type issue-type-filter">
            <p className="filter-title">Issue Type</p>
            <div className="issue-type-box">
              <input
                type="checkbox"
                checked={selectedIssueType === "Book Built"}
                onChange={(e) =>
                  setSelectedIssueType(e.target.checked ? "Book Built" : "")
                }
              />
              <span>Book Built</span>
            </div>
          </div>
        </div>

        {/* IPO Listing Section */}
        <div className="right-section">
          <div className="ipo-grid">
            {filteredIPOs
              .slice((currentPage - 1) * 6, currentPage * 6)
              .map((company, index) => (
                <IPOCard key={index} company={company} />
              ))}
          </div>

          {/* Pagination */}
          <div className="pagination">
            {filteredIPOs.length > 0 && (
              <div className="pagination-container">
                <a href="#">
                  <img
                    className="pagination-arrow"
                    onClick={() => setCurrentPage(Math.max(currentPage - 1, 1))}
                    src={left_arrow_icon}
                    alt="Previous"
                  />
                </a>
                {Array.from({
                  length: Math.ceil(filteredIPOs.length / 6),
                }).map((_, index) => (
                  <a key={index} href="#">
                    <button
                      onClick={() => setCurrentPage(index + 1)}
                      className={`pagination-button ${
                        currentPage === index + 1 ? "pagination-active" : ""
                      }`}
                    >
                      {index + 1}
                    </button>
                  </a>
                ))}
                <a href="#">
                  <img
                    className="pagination-arrow"
                    onClick={() =>
                      setCurrentPage(
                        Math.min(
                          currentPage + 1,
                          Math.ceil(filteredIPOs.length / 6)
                        )
                      )
                    }
                    src={right_arrow_icon}
                    alt="Next"
                  />
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default IPOdashboard;
