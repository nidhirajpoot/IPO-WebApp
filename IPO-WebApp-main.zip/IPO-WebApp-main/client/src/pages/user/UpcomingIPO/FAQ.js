import React, { useState } from "react";
import "./FAQ.css";

const FAQ = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const faqData = [
    {
      question: "How to Subscribe to an IPO?",
      answer: [
        "Step 1: Login to your respective service provider.",
        "Step 2: Click on the IPO button.",
        "Step 3: Select the IPO you want to bid and enter the relevant details.",
        "Step 4: Your subscription will be completed once you make the payment or give permission.",
      ],
    },
    {
      question: "Should I buy an IPO first day?",
      answer: "It depends on various factors including market conditions, company fundamentals, and your investment strategy. It's recommended to research thoroughly and consult with financial advisors before making a decision.",
    },
    {
      question: "How do you know if an IPO is good?",
      answer: "You can evaluate an IPO by analyzing factors such as company financials, business model, management team, industry prospects, valuation, and risk factors mentioned in the prospectus.",
    },
    {
      question: "How to check IPO start date?",
      answer: "IPO start dates can be checked on stock exchange websites, financial news portals, or through your trading platform. The company also announces these dates in their red herring prospectus.",
    },
    {
      question: "What is issue size?",
      answer: "Issue size refers to the total amount of money a company aims to raise through its IPO. It's calculated by multiplying the number of shares being offered with the price per share.",
    },
    {
      question: "How many shares in a lot?",
      answer: "The lot size varies for each IPO and is decided by the company. It represents the minimum number of shares an investor must bid for. This information is available in the IPO prospectus.",
    },
    {
      question: "How is the lot size calculated?",
      answer: "Lot size is typically calculated to ensure retail investors can participate within SEBI's minimum and maximum investment limits. It's determined by dividing the minimum investment amount by the price per share.",
    },
    {
      question: "Who decides the IPO price band?",
      answer: "The IPO price band is decided by the company in consultation with their investment bankers (Book Running Lead Managers) based on various factors including company valuation, market conditions, and investor feedback.",
    },
    {
      question: "What is IPO GMP?",
      answer: "GMP (Grey Market Premium) is the premium amount at which IPO shares are traded in the unofficial/grey market before they are officially listed on the stock exchange. It indicates the expected listing price.",
    },
    {
      question: "How many lots should I apply for IPO?",
      answer: "The number of lots depends on your investment capacity and strategy. Retail investors can apply for up to 13-14 lots in most IPOs, but it's important to invest based on your risk appetite and financial goals.",
    },
  ];

  const toggleAnswer = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="faq-container">
      <h2>Frequently Asked Questions?</h2>
      <p>Find answers to common questions related to IPOs.</p>
      {faqData.map((faq, index) => (
        <div
          key={index}
          className={`faq-item ${activeIndex === index ? "active" : ""}`}
        >
          <div
            className="faq-question"
            onClick={() => toggleAnswer(index)}
          >
            {faq.question}
            <span className="toggle-icon">{activeIndex === index ? "-" : "+"}</span>
          </div>
          {activeIndex === index && (
            <div className="faq-answer">
              {Array.isArray(faq.answer) ? (
                <ul>
                  {faq.answer.map((step, i) => (
                    <li key={i}>{step}</li>
                  ))}
                </ul>
              ) : (
                <p>{faq.answer}</p>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default FAQ;