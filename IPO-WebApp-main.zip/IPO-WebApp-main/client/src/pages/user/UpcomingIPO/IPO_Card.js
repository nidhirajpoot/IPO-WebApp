import React from 'react'

const IPOCard = ({ company }) => {
  const {
    logo,
    name,
    priceband,
    open,
    close,
    issueSize,
    issueType,
    listingDate
  } = company;

  return (
    <div className="ipo-card">
      <div className="company-header">
        {logo && (
          <img
            src={logo}
            alt={`${name} logo`}
            className="company-logo"
          />
        )}
        <h3 className="company-name">{name}</h3>
      </div>

      <div className="info-grid">
        <div className="info-item">
          <p className="label">PRICE BAND</p>
          <p className="value">{priceband || 'Not Issued'}</p>
        </div>
        <div className="info-item">
          <p className="label">OPEN</p>
          <p className="value">{open || 'Not Issued'}</p>
        </div>
        <div className="info-item">
          <p className="label">CLOSE</p>
          <p className="value">{close || 'Not Issued'}</p>
        </div>
      </div>

      <div className="info-grid">
        <div className="info-item">
          <p className="label">ISSUE SIZE</p>
          <p className="value">{issueSize || 'Not Issued'}</p>
        </div>
        <div className="info-item">
          <p className="label">ISSUE TYPE</p>
          <p className="value">{issueType || 'Not Issued'}</p>
        </div>
        <div className="info-item">
          <p className="label">LISTING DATE</p>
          <p className="value">{listingDate || 'Not Issued'}</p>
        </div>
      </div>

      <div className="badges">
        <span className="badge badge-rhp">RHP</span>
        <span className="badge badge-drhp">DRHP</span>
      </div>
    </div>
  );
};
export default IPOCard;