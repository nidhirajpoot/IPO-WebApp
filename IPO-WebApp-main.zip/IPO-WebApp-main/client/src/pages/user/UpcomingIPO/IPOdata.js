import novaLogo from './assets/nova.png';
import epackLogo from './assets/download-1.png';
import rkSwamyLogo from './assets/download-1-1.png';
import oravelLogo from './assets/download-2.png';
import imagineLogo from './assets/download-1-2.png';
import kidsLogo from './assets/download-2-1.png';
import olaLogo from './assets/download-2-2.png';
import mobikwikLogo from './assets/mobikwik-1.png';
import leTravenuesLogo from './assets/download-3-1.png';
import cmrGreenLogo from './assets/download-3-2.png';
import wellnessForeverLogo from './assets/download-4-1.png';
import pkhVenturesLogo from './assets/download-4-2.png';
const ipoData = [
  {
    logo: novaLogo,
    name: 'Nova Agritech Ltd.',
    priceband: 'Rs 39 - 41',
    open: '2024-01-22',
    close: '2024-01-24',
    issueSize: '143.81 Cr.',
    issueType: 'Book Built',
    listingDate: '2024-01-30'
  },
  {
    logo: epackLogo,
    name: 'EPACK Durable Ltd.',
    priceband: 'Rs 218 - 230',
    open: '2024-01-19',
    close: '2024-01-23',
    issueSize: '640.05 Cr.',
    issueType: 'Book Built',
    listingDate: '2024-01-29'
  },
  {
    logo: rkSwamyLogo,
    name: 'RK Swamy Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: 'Not Issued',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: oravelLogo,
    name: 'Gravel Stays Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: '8430 Cr.',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: imagineLogo,
    name: 'Imagine Marketing Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: '2000 cr.',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: kidsLogo,
    name: 'Kids Clinic India Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: 'Not Issued',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: olaLogo,
    name: 'OLA Electric Mobility Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: 'Not issued',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: mobikwikLogo,
    name: 'One Mobikwik Systems Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: '1900 Cr.',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: leTravenuesLogo,
    name: 'Le Travenues Technology',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: '1800 Cr.',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: cmrGreenLogo,
    name: 'CMR Green Technologies',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: 'Not Issued',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: wellnessForeverLogo,
    name: 'Wellness Forever',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: 'Not Issued',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  },
  {
    logo: pkhVenturesLogo,
    name: 'PKH Ventures Ltd.',
    priceband: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: 'Not Issued',
    issueType: 'Book Built',
    listingDate: 'Not Issued'
  }
];

export default ipoData;