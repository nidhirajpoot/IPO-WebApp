import React from "react";
import IPOdashboard from "./UpcomingIPO/IPOdashboard";
import Header from "./UpcomingIPO/Header";
import FAQ from "./UpcomingIPO/FAQ";
import Footer from "./UpcomingIPO/Footer";


const UpcomingIPO = () => {
  return (
    <>
      <div className="full-page">
        <Header />
        <IPOdashboard />
       
        <FAQ />
        <Footer />
      </div>
    </>
  );
};

export default UpcomingIPO;
