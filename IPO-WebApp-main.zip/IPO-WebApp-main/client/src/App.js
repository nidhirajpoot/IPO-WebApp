import React from 'react'
import { Route, Routes } from 'react-router-dom'
import AdminDashboard from './pages/admin/AdminDashboard'
import ManageIPO from './pages/ManageIPO/Manage'
import RegisterIPO from './pages/RegisterIPO/Register'
import UpcomingIPO from './pages/user/Layout'
import SignUp from './pages/authentication/SignUp'
import SignIn from './pages/authentication/SignIn'
import ForgotPassword from './pages/authentication/ForgotPassword'
import './App.css'

const App = () => {
  const username = "Vishal";
  return (
    <>
      <Routes>
        <Route path="/SignUp" element={<SignUp />} />
        <Route path="/SignIn" element={<SignIn />} />
        <Route path="/ForgotPassword" element={<ForgotPassword />} />
        <Route path="/" element={<AdminDashboard />} />
        <Route path="/ManageIPO" element={<ManageIPO username={username} />} />
        <Route path="/register" element={<RegisterIPO />} />
        <Route path="/UpcomingIPO" element={<UpcomingIPO />} />
      </Routes>
    </>
  );
};

export default App