import express from "express";
import dotenv from "dotenv";
import cors from 'cors'
import pool from "./config/db.js";
import upcomingIpos from './ipo_data.js'
//configure env
dotenv.config();

//rest object
const app = express();

const port = process.env.PORT || 3001;

//middleware
app.use(express.json());
app.use(cors());

//routes

//error handling middleware

//testing postgres connection
app.get("/", async (req, res) => {
    const result = await pool.query("SELECT current_database()");
    console.log("end");
    res.send(`The database name is : ${result.rows[0].current_database}`);
});
// API Route to fetch all upcoming IPOs
// API Route to fetch all upcoming IPOs
app.get("/api/ipos", (req, res) => {
    console.log("API Request received at /api/ipos");
    res.json(upcomingIpos); // Corrected variable name
  });
  
//server running
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});


  