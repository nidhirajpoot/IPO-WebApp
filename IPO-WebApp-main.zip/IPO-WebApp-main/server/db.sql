--1) help -> \?
--2) show databases -> \l
--3) create database -> CREATE DATABASE database_name;

-- Create the database
CREATE DATABASE ipo_webapp;

-- Connect to the database
\c ipo_webapp

-- Create companies table
CREATE TABLE companies (
    company_id SERIAL PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL,
    company_logo_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create ipo_information table
CREATE TABLE ipo_information (
    ipo_id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES companies(company_id),
    price_band VARCHAR(50),
    open_date DATE,
    close_date DATE,
    issue_size VARCHAR(50),
    issue_type VARCHAR(20) CHECK (issue_type IN ('public', 'private')),
    listing_date DATE,
    status VARCHAR(20) CHECK (status IN ('active', 'closed', 'upcoming', 'listed')),
    ipo_price DECIMAL(10,2),
    listing_price DECIMAL(10,2),
    listing_gain DECIMAL(10,2),
    final_listing_date DATE,
    cmp DECIMAL(10,2),
    current_return DECIMAL(10,2),
    rhp_url TEXT,
    drhp_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create a function to update timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updating timestamp
CREATE TRIGGER update_ipo_information_updated_at
    BEFORE UPDATE ON ipo_information
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create indices for better performance
CREATE INDEX idx_company_name ON companies(company_name);
CREATE INDEX idx_ipo_status ON ipo_information(status);
CREATE INDEX idx_listing_date ON ipo_information(listing_date);